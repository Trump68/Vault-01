The leftmost column contains random test images, while the remaining columns show a random subset of the feature activation maps in the layer indicated by the filename.

The order of the layers in the net is
data -> conv1 -> pool1 -> conv2 -> pool2 -> conv3 -> conv4 -> conv5 -> pool3
