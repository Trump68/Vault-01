These are top-5 predictions for random images from the test set.
