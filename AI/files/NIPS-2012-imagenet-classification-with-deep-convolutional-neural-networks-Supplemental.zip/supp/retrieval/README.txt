The leftmost column contains random test images, while the remaining columns show the nearest neighbors in the training set.
